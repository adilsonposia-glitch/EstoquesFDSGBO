import { cn } from '@/lib/utils'

function Input({
  className,
  type,
  style,
  ...props
}: React.ComponentProps<'input'>) {
  return (
    <input
      type={type}
      data-slot="input"
      style={{
        paddingInline: 'var(--field-px)',
        paddingBlock: 'var(--field-py)',
        ...style,
      }}
      className={cn(
        'flex w-full min-w-0 rounded-xl border border-input bg-background text-sm shadow-sm transition-[color,box-shadow] outline-none',
        'placeholder:text-muted-foreground',
        'focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/25',
        'disabled:cursor-not-allowed disabled:opacity-50',
        'aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20',
        'file:border-0 file:bg-transparent file:text-sm file:font-medium',
        className,
      )}
      {...props}
    />
  )
}

export { Input }
